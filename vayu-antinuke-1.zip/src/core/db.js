const Database = require('@replit/database');
const db = new Database();
module.exports = db;