const prefix = process.env.prefix || ';'
const status = `${prefix}help`;


module.exports = {
  bot: {
    info: {
      prefix: process.env.prefix || ';',
      token: process.env.token,
      invLink: 'https://discord.com/api/oauth2/authorize?client_id=&permissions=8&scope=bot',
    },
    options: {
      founders: ['947891831516065834'],
      privateMode: false,
    },
    presence: {
      name: process.env.statusText || 'powered by ＱＵＴＹＰＩＥ<3',
      type: 'PLAYING',
      url: 'https://twitch.tv/pewdiepie'
    },
    credits: {
      developerId: '947891831516065834',
      developer: 'ＱＵＴＹＰＩＥ<3#7891',

      supportServer: 'https://discord.gg/Rqdx38Gdfn'
    }
  }
}
